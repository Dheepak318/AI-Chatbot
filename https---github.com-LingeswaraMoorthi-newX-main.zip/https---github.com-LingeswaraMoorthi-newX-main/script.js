/* --- Configuration --- */
const CONFIG = {
  typingDelay: 800, // ms to show typing indicator
  botName: 'College Assistant',
  useBackend: false // Set to true if backend is running
};

/* --- State --- */
let isDarkTheme = false;
let synthesis = window.speechSynthesis;
let currentIntent = null; // Track the last matched main intent for sub-intent checks

/* --- Initialization --- */
document.addEventListener('DOMContentLoaded', () => {
  initChat();
  loadTheme();
});

function initChat() {
  const input = document.getElementById('userInput');
  
  // Enter key support
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  });

  // Theme toggle
  document.getElementById('theme-toggle').addEventListener('click', toggleTheme);

  // Voice input
  document.getElementById('voiceBtn').addEventListener('click', startVoiceInput);

  // Load static responses
  fetch('responses.json')
    .then(r => r.ok ? r.json() : [])
    .then(data => { if(Array.isArray(data)) RESPONSES.push(...data); })
    .catch(console.warn);

  // Load history
  loadHistory();
}

/* --- Core Chat Logic --- */
function sendMessage() {
  const inputEl = document.getElementById("userInput");
  const text = (inputEl.value || "").trim();
  if (!text) return;

  // Add user message
  addMessage("You", text, "user");
  inputEl.value = "";

  // Show typing indicator
  showTyping(true);

  // Process response
  const reply = getBotReply(text);

  // Simulate delay for "thinking"
  setTimeout(() => {
    showTyping(false);
    addMessage(CONFIG.botName, reply, "bot");
    speakResponse(reply);
  }, CONFIG.typingDelay);
}

function getBotReply(input) {
  const text = input.toLowerCase();
  
  // 1. Check Intents
  const intent = classifyIntent(text);
  if (intent) {
    if (intent.replies) return random(intent.replies);
  }

  // 2. Check Static Patterns
  for (const entry of RESPONSES) {
    if (entry.keywords && entry.keywords.some(k => matchKeyword(text, k))) {
      return random(entry.replies);
    }
  }

  // 3. Fallback
  return "I'm not sure about that. Please contact the administration office or try asking differently.";
}

/* --- UI Functions --- */
function addMessage(sender, text, type) {
  const chatBox = document.getElementById("chat-box");
  
  const msgDiv = document.createElement("div");
  msgDiv.className = `message ${type}`;
  
  const contentDiv = document.createElement("div");
  contentDiv.className = "message-content";
  contentDiv.innerText = text; // Safe text insertion
  
  const tsDiv = document.createElement("div");
  tsDiv.className = "ts";
  tsDiv.innerText = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

  msgDiv.appendChild(contentDiv);
  msgDiv.appendChild(tsDiv);
  chatBox.appendChild(msgDiv);
  
  scrollToBottom();
  saveHistory(sender, text, type);
}

function showTyping(show) {
  const indicator = document.getElementById('typingIndicator');
  indicator.style.display = show ? 'flex' : 'none';
  if(show) scrollToBottom();
}

function scrollToBottom() {
  const chatBox = document.getElementById("chat-box");
  chatBox.scrollTop = chatBox.scrollHeight;
}

function fillInput(text) {
  const input = document.getElementById('userInput');
  input.value = text;
  input.focus();
  // Optional: Auto-send
  // sendMessage();
}

/* --- Theme Logic --- */
function toggleTheme() {
  isDarkTheme = !isDarkTheme;
  document.documentElement.setAttribute('data-theme', isDarkTheme ? 'dark' : 'light');
  const icon = document.querySelector('#theme-toggle i');
  icon.className = isDarkTheme ? 'fas fa-sun' : 'fas fa-moon';
  localStorage.setItem('theme', isDarkTheme ? 'dark' : 'light');
}

function loadTheme() {
  const savedTheme = localStorage.getItem('theme');
  if (savedTheme) {
    isDarkTheme = savedTheme === 'dark';
    document.documentElement.setAttribute('data-theme', savedTheme);
    const icon = document.querySelector('#theme-toggle i');
    icon.className = isDarkTheme ? 'fas fa-sun' : 'fas fa-moon';
  } else if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
    toggleTheme();
  }
}

/* --- Voice Interaction --- */
let isListening = false;
let recognition = null;

function startVoiceInput() {
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SpeechRecognition) {
    alert("Voice input is not supported in this browser. Please use Chrome or Edge.");
    return;
  }

  if (isListening) {
    // Stop listening
    if (recognition) {
      recognition.stop();
    }
    return;
  }

  recognition = new SpeechRecognition();
  recognition.lang = 'en-US';
  recognition.continuous = false;
  recognition.interimResults = true; // Enable interim results for feedback

  const btn = document.getElementById('voiceBtn');
  const icon = btn.querySelector('i');

  recognition.onstart = () => {
    isListening = true;
    btn.style.color = 'red'; // Visual cue
    icon.className = 'fas fa-stop'; // Change icon to stop
    console.log('Voice recognition started');
  };

  recognition.onresult = (event) => {
    let finalTranscript = '';
    let interimTranscript = '';

    for (let i = event.resultIndex; i < event.results.length; i++) {
      const transcript = event.results[i][0].transcript;
      if (event.results[i].isFinal) {
        finalTranscript += transcript;
      } else {
        interimTranscript += transcript;
      }
    }

    const input = document.getElementById('userInput');
    input.value = finalTranscript || interimTranscript; // Show interim or final
    console.log('Transcript:', finalTranscript || interimTranscript);
  };

  recognition.onend = () => {
    isListening = false;
    btn.style.color = ''; // Reset
    icon.className = 'fas fa-microphone'; // Reset icon
    console.log('Voice recognition ended');
  };

  recognition.onerror = (event) => {
    console.error('Speech recognition error:', event.error);
    isListening = false;
    btn.style.color = '';
    icon.className = 'fas fa-microphone';
    if (event.error === 'not-allowed') {
      alert('Microphone access is blocked. Please allow microphone permission in your browser settings:\n\n1. Click the lock icon in the address bar\n2. Allow microphone access\n3. Or go to browser settings > Privacy > Microphone > Allow for localhost');
    } else {
      alert('Voice recognition error: ' + event.error);
    }
  };

  try {
    recognition.start();
  } catch (e) {
    console.error('Error starting recognition:', e);
    alert('Error starting voice recognition: ' + e.message);
  }
}

function speakResponse(text) {
  if (!synthesis) return;
  const utterance = new SpeechSynthesisUtterance(text);
  synthesis.speak(utterance);
}

/* --- History Management --- */
const HISTORY_KEY = 'chat_history_v2';

function saveHistory(sender, text, type) {
  const history = JSON.parse(localStorage.getItem(HISTORY_KEY) || '[]');
  history.push({ sender, text, type, time: new Date().toISOString() });
  // Keep last 50 messages
  if (history.length > 50) history.shift();
  localStorage.setItem(HISTORY_KEY, JSON.stringify(history));
}

function loadHistory() {
  const history = JSON.parse(localStorage.getItem(HISTORY_KEY) || '[]');
  const chatBox = document.getElementById("chat-box");
  // Clear default welcome if history exists
  if(history.length > 0) {
    chatBox.innerHTML = ''; 
    history.forEach(msg => {
      const msgDiv = document.createElement("div");
      msgDiv.className = `message ${msg.type}`;
      
      const contentDiv = document.createElement("div");
      contentDiv.className = "message-content";
      contentDiv.innerText = msg.text;
      
      const tsDiv = document.createElement("div");
      tsDiv.className = "ts";
      const date = new Date(msg.time);
      tsDiv.innerText = date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

      msgDiv.appendChild(contentDiv);
      msgDiv.appendChild(tsDiv);
      chatBox.appendChild(msgDiv);
    });
    scrollToBottom();
  }
}

/* --- Data & Helper Functions --- */
function random(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}

// Tokenize a string into lowercase alphanumeric words
function tokenize(s) {
  return (s || '').toLowerCase().split(/[^a-z0-9]+/).filter(Boolean);
}

// Match keyword against text using tokenized whole-word (or sequential multi-word) matching
function matchKeyword(text, keyword) {
  const t = tokenize(text);
  const k = tokenize(keyword);
  if (k.length === 0) return false;
  if (k.length === 1) return t.includes(k[0]);
  // look for sequence
  for (let i = 0; i <= t.length - k.length; i++) {
    let ok = true;
    for (let j = 0; j < k.length; j++) {
      if (t[i + j] !== k[j]) { ok = false; break; }
    }
    if (ok) return true;
  }
  return false;
}

// Re-using the intent logic from previous version, slightly cleaned up
const RESPONSES = [
  // Fallback patterns
];


const INTENTS = [
  { id: 'greeting', keywords: ['hello','hi','hey','good morning'], replies: ['Hello! How can I help you today?', 'Hi there! Ask me about admissions or courses.'] },
  
  { id: 'admission', keywords: ['admission','admissions','apply','join'], replies: ['Admissions start in June for the 2026 batch. You can apply online via our website.'] },

  { id: 'fees', keywords: ['fees','fee','tuition','cost'], replies: ['Fee structures vary by course & Time. Please contact the accounts office for detailed breakdowns.'] },

  { id: 'timing', keywords: ['timing','time','open'], replies: ['College hours are 9:00 AM to 2:00 PM in Monday to Thursday, Friday 9:00 AM to 1:00 PM.'] },

  { id: 'contact', keywords: ['contact','phone','email','address'], replies: ['You can reach us at mscas@gmail.com or  044 2450 1115'] },
  
  { id: 'cultural_events', keywords: ['events','cultural','fest','celebration','function'], replies: ['We host various cultural events throughout the year,Especially in our college Pongal celebration and Onum celebration are very famous. Check our website for the latest updates.'] },
  
  { id: 'library', keywords: ['library','hours','books','reading','resources'], replies: ['Our library is open from 9:00 AM to 6:00 PM on weekdays. It has a vast collection of books and digital resources.'] },

  { id: 'sports_facilities', keywords: ['sports','facilities','games'], replies: ['We have excellent sports facilities including a cricket ground, football ground, basketball court and volleyball court, apart from these there are many sports we have organized for students.'] },

  { id: 'scholarships', keywords: ['scholarship','scholarships','financial aid','funding'], replies: ['We offer various scholarships based on SE ST minority. Please visit our financial aid office for more details.'] },

  { id: 'hostel', keywords: ['hostel','dorm','accommodation','stay'], replies: ['We provide on-campus hostel facilities (with sharing and without sharing rooms)  for students. Please contact the hostel warden or college admin for availability and rules.'] },

  { id: 'transport', keywords: ['transport','bus','commute','travel'], replies: ['We have a college bus service covering major routes in the city. Check the transport office or college admin for schedules and routes.'] },

  { id: 'faculty', keywords: ['faculty','teachers','staff','professors'], replies: ['Our faculty members are highly qualified and experienced in their respective fields. You can find more information on our website.'] },

  { id: 'placements', keywords: ['placements','jobs','career','internship'], replies: ['We have a dedicated placement cell that assists students with internships and job placements (Many company will arrive for placements).'] },

  { id: 'infrastructure', keywords: ['infrastructure','facilities','campus','buildings'], replies: ['Our campus boasts modern infrastructure with state-of-the-art classrooms, labs, and recreational areas.'] }, 
   
  { id: 'events', keywords: ['seminar','workshop','conference','webinar'], replies: ['We regularly organize seminars, workshops, and conferences. Please check our events calendar on the website for upcoming events.'] },

  { 
    id: 'courses',
    keywords: ['courses','course','programs','offer'], 
    replies: ['We are offering various under graduate & post graduate programs including BSc, BCA, BBA, BA, B.com, MCA, MSc, MBA, M.com, M.phil, Ph.D. PG Diploma in E-Business Management and Diploma in Catering Technology Which course are you interested in?'],
    subIntents: [
      { 
        id: 'course_bsc', 
        keywords: ['bsc', 'b.sc' ,'BSC'], 
        replies: [
            'We are offering many BSc courses in various specializations which department are you interested in? Bsc Computer Science, Bsc Mathematics, Bsc Chemistry, Bsc Microbiology, BSC Biotechnology, Bsc Biochemistry, BSC Visual Communication, Bsc Home Science, BSC Phycology, BSC Electronics & Communication Science, Bsc Hotel & Catering Management. For syllabus and admission criteria, please visit our website or contact the office.'] 
      },
      { 
        id: 'course_ba', 
        keywords: ['ba', 'b.a', 'BA'], 
        replies: [
            'We are offering BA English courses for undergraduate studies. For syllabus and admission criteria, please visit our website or contact the office.'] 
      },
      { 
        id: 'course_bcom', 
        keywords: ['bcom', 'b.com', 'BCOM'], 
        replies: ['We are offering BCom courses in various specializations. which department are you interested in? BCom General, BCom Accounting & Finance, BCom Corporate Secretaryship, BCom Computer Applications (often referred as B.Com CA or B.Com CS), BCom Banking Management, Bcom Information Systems, . For syllabus and admission criteria, please visit our website or contact the office.'] 
      },
      {
        id: 'course_bba', 
        keywords: ['bba', 'b.b.a', 'BBA'], 
        replies: ['We are offering BBA courses for undergraduate studies. For syllabus and admission criteria, please visit our website or contact the office.'] 
      },
      {
        id: 'course_bca', 
        keywords: ['bca', 'b.c.a', 'BCA'], 
        replies: ['We are offering BCA courses for undergraduate studies. For syllabus and admission criteria, please visit our website or contact the office.'] 
      },
      {
        id: 'course_mca', 
        keywords: ['mca', 'm.c.a', 'MCA'], 
        replies: ['We are offering MCA courses for postgraduate studies. For syllabus and admission criteria, please visit our website or contact the office.']     
      },
      {
        id: 'course_mba', 
        keywords: ['mba', 'm.b.a', 'MBA'], 
        replies: ['We are offering MBA courses for postgraduate studies. For syllabus and admission criteria, please visit our website or contact the office.'] 
      },
      {
        id: 'course_msc', 
        keywords: ['msc', 'm.sc', 'MSC'], 
        replies: ['We are offering MSc courses in various specializations which department are you interested in? MSc Computer Science, MSc Mathematics, MSC Biochemistry MSc Microbiology, MSc Biotechnology, MSc Electronics & Communication Science. For syllabus and admission criteria, please visit our website or contact the office.']
      },
      {
        id: 'course_phd', 
        keywords: ['phd', 'Ph.D', 'PhD'], 
        replies: ['We are offering PhD programs in Biotechnology, Microbiology, and Biochemistry. For more details on research areas and admission criteria, please visit our website or contact the research office.']
      },
      {
        id: 'course_mphil',
        keywords: ['mphil', 'm.phil', 'MPhil'],
        replies: ['We are offering MPhil programs in Biotechnology, Microbiology, and Biochemistry. For more details on research areas and admission criteria, please visit our website or contact the research office.']
      },
      {
        id: 'course_pg_diploma',
        keywords: ['diploma', 'postgraduate diploma', 'post graduate diploma'],
        replies: ['We are offering a PG Diploma in E-Business Management and Diploma in Catering Technology. For syllabus and admission criteria, please visit our website or contact the office.']
      }
    ]
  }
];

function classifyIntent(text) {
  const lowerText = text.toLowerCase();
  
  // 1. Check sub-intents of the current intent (if in a conversation context)
  if (currentIntent && currentIntent.subIntents) {
    for (const subIntent of currentIntent.subIntents) {
      for (const kw of subIntent.keywords) {
        if (matchKeyword(lowerText, kw)) {
          return subIntent; // Return the sub-intent
        }
      }
    }
  }

  // 2. Check for direct course mentions (for backward compatibility)
  for (const intent of INTENTS) {
    if (intent.subIntents) {
      for (const subIntent of intent.subIntents) {
        for (const kw of subIntent.keywords) {
          if (matchKeyword(lowerText, kw)) {
            currentIntent = intent; // Set main intent
            return subIntent;
          }
        }
      }
    }
  }

  // 3. Check main intents
  for (const intent of INTENTS) {
    for (const kw of intent.keywords) {
      if (matchKeyword(lowerText, kw)) {
        currentIntent = intent; // Set as current intent for potential sub-intents
        return intent;
      }
    }
  }

  // 4. No match
  return null;
}